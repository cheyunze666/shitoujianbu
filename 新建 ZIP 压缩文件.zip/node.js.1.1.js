const readline = require('readline');
const WebSocket = require('ws');
const http = require('http');
const os = require('os');
const { v4: uuidv4 } = require('uuid');
const Peer = require('simple-peer');

// 游戏状态和配置
let gameState = {
  playerScore: 0,
  opponentScore: 0,
  round: 1,
  maxRounds: 3,
  aiDifficulty: 'medium', // easy, medium, hard
  gameMode: null, // 'single', 'lan_host', 'lan_client', 'p2p_host', 'p2p_client'
  peer: null,
  connection: null,
  playerId: uuidv4(),
  roomId: null,
  isMyTurn: false,
  server: null,
  wss: null
};

// 创建命令行接口
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// 清屏函数
function clearScreen() {
  process.stdout.write('\x1Bc');
}

// 显示开始界面
function showStartScreen() {
  clearScreen();
  console.log('========================================');
  console.log('   🪨 ✂️ 📃 石头剪刀布游戏 - 终极版  ');
  console.log('========================================');
  console.log('1. 🎮 单人游戏');
  console.log('2. 🌐 创建局域网房间');
  console.log('3. 🔌 加入局域网游戏');
  console.log('4. 🤝 创建P2P房间');
  console.log('5. 🔗 加入P2P游戏');
  console.log('6. 📖 游戏规则');
  console.log('7. 👤 关于作者');
  console.log('8. 🔓 开源地址');
  console.log('9. 🚪 退出游戏');
  console.log('========================================');
  rl.question('请选择操作 (1-9): ', handleStartMenu);
}

// 处理开始菜单选择
function handleStartMenu(choice) {
  switch (choice) {
    case '1':
      gameState.gameMode = 'single';
      selectDifficulty();
      break;
    case '2':
      createLanRoom();
      break;
    case '3':
      joinLanGame();
      break;
    case '4':
      createP2PRoom();
      break;
    case '5':
      joinP2PGame();
      break;
    case '6':
      showGameRules();
      break;
    case '7':
      showAboutAuthor();
      break;
    case '8':
      showOpenSource();
      break;
    case '9':
    default:
      console.log('感谢游玩，再见！👋');
      exitGame();
  }
}

// 退出游戏
function exitGame() {
  if (gameState.peer) {
    gameState.peer.destroy();
    gameState.peer = null;
  }
  if (gameState.server) {
    gameState.server.close();
    gameState.server = null;
  }
  if (gameState.wss) {
    gameState.wss.close();
    gameState.wss = null;
  }
  rl.close();
  process.exit(0);
}

// 选择AI难度
function selectDifficulty() {
  clearScreen();
  console.log('============= 选择AI难度 =============');
  console.log('1. 🟢 简单 - AI随机出拳');
  console.log('2. 🟡 中等 - AI有策略地出拳');
  console.log('3. 🔴 困难 - AI会预测你的出拳');
  console.log('====================================');
  rl.question('请选择难度 (1-3): ', (choice) => {
    switch (choice) {
      case '1':
        gameState.aiDifficulty = 'easy';
        break;
      case '2':
        gameState.aiDifficulty = 'medium';
        break;
      case '3':
        gameState.aiDifficulty = 'hard';
        break;
      default:
        gameState.aiDifficulty = 'medium';
    }
    startGame();
  });
}

// 开始游戏
function startGame() {
  gameState.playerScore = 0;
  gameState.opponentScore = 0;
  gameState.round = 1;
  playRound();
}

// 进行一局游戏
function playRound() {
  clearScreen();
  console.log(`============= 第 ${gameState.round} 局 =============`);
  console.log(`玩家: ${gameState.playerScore}  |  ${getOpponentName()}: ${gameState.opponentScore}`);
  console.log('====================================');
  console.log('1. 🪨 石头');
  console.log('2. ✂️ 剪刀');
  console.log('3. 📃 布');
  console.log('0. ↩️ 返回主菜单');
  console.log('====================================');
  
  // 在联机模式中，如果不是自己的回合，则等待
  if (gameState.gameMode !== 'single' && !gameState.isMyTurn) {
    console.log('\n等待对手出拳中...⏳');
    return;
  }
  
  rl.question('请选择你的出拳 (1-3) 或返回 (0): ', (choice) => {
    if (choice === '0') {
      resetGameState();
      showStartScreen();
      return;
    }
    
    const playerChoice = parseInt(choice);
    if (playerChoice < 1 || playerChoice > 3) {
      console.log('无效的选择，请重新输入！');
      setTimeout(playRound, 1500);
      return;
    }
    
    if (gameState.gameMode === 'single') {
      const aiChoice = generateAIChoice(playerChoice);
      const result = determineWinner(playerChoice, aiChoice);
      displayResult(playerChoice, aiChoice, result);
    } else if (gameState.gameMode.startsWith('lan')) {
      // 局域网模式：发送选择给服务器
      if (gameState.connection) {
        gameState.connection.send(JSON.stringify({
          type: 'choice',
          choice: playerChoice,
          playerId: gameState.playerId
        }));
        console.log('已发送你的选择，等待对手...');
        gameState.isMyTurn = false;
      }
    } else if (gameState.gameMode.startsWith('p2p')) {
      // P2P模式：发送选择给对手
      if (gameState.connection) {
        gameState.connection.send(JSON.stringify({
          type: 'choice',
          choice: playerChoice,
          playerId: gameState.playerId
        }));
        console.log('已发送你的选择，等待对手...');
        gameState.isMyTurn = false;
      }
    }
  });
}

// 获取对手名称
function getOpponentName() {
  switch (gameState.gameMode) {
    case 'single': return 'AI';
    case 'lan_host': return '玩家2';
    case 'lan_client': return '玩家1';
    case 'p2p_host': return '对手';
    case 'p2p_client': return '对手';
    default: return '对手';
  }
}

// 生成AI的选择
function generateAIChoice(playerChoice) {
  switch (gameState.aiDifficulty) {
    case 'easy':
      // 完全随机
      return Math.floor(Math.random() * 3) + 1;
    case 'hard':
      // 困难模式：尝试预测玩家行为并反制
      const rand = Math.random();
      if (rand < 0.4) {
        // 反制玩家最常出的拳
        return (playerChoice % 3) + 1;
      } else if (rand < 0.7) {
        return playerChoice; // 平局
      } else {
        return Math.floor(Math.random() * 3) + 1;
      }
    case 'medium':
    default:
      // 中等模式：有一定策略
      if (Math.random() < 0.6) {
        return (playerChoice % 3) + 1;
      }
      return Math.floor(Math.random() * 3) + 1;
  }
}

// 判断胜负
function determineWinner(player, opponent) {
  // 石头(1) > 剪刀(2)
  // 剪刀(2) > 布(3)
  // 布(3) > 石头(1)
  if (player === opponent) return 'draw';
  
  if (
    (player === 1 && opponent === 2) ||
    (player === 2 && opponent === 3) ||
    (player === 3 && opponent === 1)
  ) {
    return 'win';
  }
  
  return 'lose';
}

// 显示结果
function displayResult(playerChoice, opponentChoice, result) {
  clearScreen();
  const choices = ['石头 🪨', '剪刀 ✂️', '布 📃'];
  
  console.log('================ 结果 ================');
  console.log(`你出了: ${choices[playerChoice - 1]}`);
  console.log(`${getOpponentName()}出了: ${choices[opponentChoice - 1]}`);
  
  switch (result) {
    case 'win':
      gameState.playerScore++;
      console.log('🎉 你赢了这一局！');
      break;
    case 'lose':
      gameState.opponentScore++;
      console.log('😢 你输了这一局！');
      break;
    case 'draw':
      console.log('🤝 平局！');
      break;
  }
  
  console.log('====================================');
  
  // 检查游戏是否结束
  if (gameState.playerScore >= gameState.maxRounds || gameState.opponentScore >= gameState.maxRounds) {
    setTimeout(endGame, 2000);
  } else {
    gameState.round++;
    setTimeout(playRound, 2000);
  }
}

// 结束游戏
function endGame() {
  clearScreen();
  console.log('============== 游戏结束 ==============');
  console.log(`最终比分: 玩家 ${gameState.playerScore} - ${gameState.opponentScore} ${getOpponentName()}`);
  
  if (gameState.playerScore > gameState.opponentScore) {
    console.log('🏆 恭喜你获得胜利！');
  } else if (gameState.playerScore < gameState.opponentScore) {
    console.log('💔 很遗憾，你输了！');
  } else {
    console.log('🤝 平局！势均力敌！');
  }
  
  console.log('====================================');
  rl.question('按回车键返回主菜单...', () => {
    resetGameState();
    showStartScreen();
  });
}

// 重置游戏状态
function resetGameState() {
  if (gameState.peer) {
    gameState.peer.destroy();
    gameState.peer = null;
  }
  if (gameState.server) {
    gameState.server.close();
    gameState.server = null;
  }
  if (gameState.wss) {
    gameState.wss.close();
    gameState.wss = null;
  }
  gameState.connection = null;
  gameState.roomId = null;
  gameState.isMyTurn = false;
}

// 显示游戏规则
function showGameRules() {
  clearScreen();
  console.log('============= 游戏规则 =============');
  console.log('1. 石头、剪刀、布分别用数字代表:');
  console.log('   🪨 1 - 石头');
  console.log('   ✂️ 2 - 剪刀');
  console.log('   📃 3 - 布');
  console.log('2. 胜负规则:');
  console.log('   石头(1) 赢 剪刀(2)');
  console.log('   剪刀(2) 赢 布(3)');
  console.log('   布(3) 赢 石头(1)');
  console.log('3. 游戏采用三局两胜制');
  console.log('4. 游戏模式:');
  console.log('   - 单人模式: 与AI对战');
  console.log('   - 局域网联机: 在同一个网络下与朋友对战');
  console.log('   - P2P联机: 通过互联网与朋友对战');
  console.log('====================================');
  rl.question('按回车键返回主菜单...', showStartScreen);
}

// 显示关于作者
function showAboutAuthor() {
  clearScreen();
  console.log('============= 关于作者 =============');
  console.log('作者: 烂香蕉 🍌');
  console.log('简介: 一个热爱编程的游戏开发者');
  console.log('创作理念: 创造有趣且富有挑战性的游戏体验');
  console.log('特别提示: 本游戏中的AI具有学习能力，难度越高越聪明！版本号：1.1');
  console.log('====================================');
  rl.question('按回车键返回主菜单...', showStartScreen);
}

// 显示开源地址
function showOpenSource() {
  clearScreen();
  console.log('============= 开源地址 =============');
  console.log('本游戏完全开源，代码托管在GitHub:');
  console.log('https://github.com/cheyunze666/-');
  console.log('欢迎贡献代码或提出改进建议！');
  console.log('====================================');
  rl.question('按回车键返回主菜单...', showStartScreen);
}

// 创建局域网房间
function createLanRoom() {
  clearScreen();
  console.log('========= 创建局域网游戏房间 =========');
  
  // 获取本机IP地址
  const networkInterfaces = os.networkInterfaces();
  let ipAddress = '127.0.0.1';
  
  Object.keys(networkInterfaces).forEach((interfaceName) => {
    networkInterfaces[interfaceName].forEach((network) => {
      if (network.family === 'IPv4' && !network.internal) {
        ipAddress = network.address;
      }
    });
  });
  
  console.log(`你的IP地址: ${ipAddress}`);
  
  rl.question('请输入端口号 (默认: 8080): ', (port) => {
    const portNumber = port || 8080;
    
    // 创建HTTP服务器和WebSocket服务器
    gameState.server = http.createServer();
    gameState.wss = new WebSocket.Server({ server: gameState.server });
    
    let player1 = null;
    let player2 = null;
    
    gameState.wss.on('connection', (ws) => {
      // 分配玩家
      if (!player1) {
        player1 = ws;
        console.log('玩家1已连接！');
        ws.send(JSON.stringify({ type: 'role', role: 'player1' }));
      } else if (!player2) {
        player2 = ws;
        console.log('玩家2已连接！游戏开始！');
        ws.send(JSON.stringify({ type: 'role', role: 'player2' }));
        
        // 通知玩家1游戏开始
        player1.send(JSON.stringify({ type: 'start' }));
        player2.send(JSON.stringify({ type: 'start' }));
        
        // 设置游戏状态
        gameState.gameMode = 'lan_host';
        gameState.connection = player1; // 主机作为玩家1
        gameState.isMyTurn = true;
        startGame();
      } else {
        console.log('房间已满，拒绝连接');
        ws.close();
      }
      
      ws.on('message', (message) => {
        const data = JSON.parse(message);
        
        if (data.type === 'choice') {
          // 转发选择给对手
          if (ws === player1 && player2) {
            player2.send(JSON.stringify({ 
              type: 'opponent_choice', 
              choice: data.choice 
            }));
          } else if (ws === player2 && player1) {
            player1.send(JSON.stringify({ 
              type: 'opponent_choice', 
              choice: data.choice 
            }));
          }
        }
      });
      
      ws.on('close', () => {
        if (ws === player1) {
          player1 = null;
          console.log('玩家1断开连接');
        } else if (ws === player2) {
          player2 = null;
          console.log('玩家2断开连接');
        }
      });
    });
    
    gameState.server.listen(portNumber, () => {
      console.log(`房间已创建，等待玩家加入...`);
      console.log(`其他玩家可以使用IP: ${ipAddress} 和端口: ${portNumber} 加入游戏`);
      console.log('等待连接中...');
    });
  });
}

// 加入局域网游戏
function joinLanGame() {
  clearScreen();
  console.log('============ 加入局域网游戏 ===========');
  
  rl.question('请输入主机IP地址: ', (ip) => {
    rl.question('请输入端口号 (默认: 8080): ', (port) => {
      const portNumber = port || 8080;
      const ws = new WebSocket(`ws://${ip}:${portNumber}`);
      
      ws.on('open', () => {
        console.log('已连接到主机！');
      });
      
      ws.on('message', (message) => {
        const data = JSON.parse(message);
        
        if (data.type === 'role') {
          gameState.gameMode = 'lan_client';
          gameState.connection = ws;
          console.log(`你的角色: ${data.role}`);
        }
        else if (data.type === 'start') {
          console.log('游戏开始！');
          gameState.isMyTurn = (gameState.gameMode === 'lan_client');
          startGame();
        }
        else if (data.type === 'opponent_choice') {
          const opponentChoice = parseInt(data.choice);
          const playerChoice = 0; // 在局域网模式中，我们不需要玩家的选择来显示结果
          
          clearScreen();
          const choices = ['石头 🪨', '剪刀 ✂️', '布 📃'];
          
          console.log('================ 结果 ================');
          console.log(`你出了: ${choices[playerChoice] || '等待中...'}`);
          console.log(`对手出了: ${choices[opponentChoice - 1]}`);
          console.log('结果计算中...');
          console.log('====================================');
          
          // 设置轮到我出拳
          gameState.isMyTurn = true;
          
          setTimeout(() => {
            playRound();
          }, 2000);
        }
      });
      
      ws.on('error', (error) => {
        console.log('连接失败，请检查IP和端口是否正确');
        console.log('错误信息:', error.message);
        rl.question('按回车键返回主菜单...', showStartScreen);
      });
    });
  });
}

// 创建P2P房间
function createP2PRoom() {
  clearScreen();
  console.log('========= 创建P2P联机游戏房间 =========');
  
  // 生成房间ID
  gameState.roomId = Math.floor(1000 + Math.random() * 9000);
  gameState.isMyTurn = true;
  
  // 创建Peer实例
  gameState.peer = new Peer({ initiator: true, trickle: false });
  
  // 生成信号数据
  gameState.peer.on('signal', (data) => {
    console.log(`你的房间ID: ${gameState.roomId}`);
    console.log('请将以下信号数据提供给对手:');
    console.log('------------------------------------');
    console.log(JSON.stringify(data));
    console.log('------------------------------------');
    console.log('等待对手连接中...');
  });
  
  // 当收到对手信号时
  gameState.peer.on('data', (data) => {
    const message = JSON.parse(data.toString());
    
    if (message.type === 'signal') {
      gameState.peer.signal(message.data);
    } else if (message.type === 'choice') {
      // 处理对手的选择
      handleOpponentChoice(message.choice);
    }
  });
  
  // 当连接建立时
  gameState.peer.on('connect', () => {
    console.log('对手已连接！游戏开始！');
    gameState.connection = gameState.peer;
    gameState.gameMode = 'p2p_host';
    startGame();
  });
  
  rl.question('按回车键返回主菜单...', showStartScreen);
}

// 加入P2P游戏
function joinP2PGame() {
  clearScreen();
  console.log('============ 加入P2P游戏 ===========');
  
  rl.question('请输入房间ID: ', (roomId) => {
    rl.question('请输入主机信号数据: ', (signalData) => {
      try {
        const signal = JSON.parse(signalData);
        gameState.isMyTurn = false;
        
        // 创建Peer实例
        gameState.peer = new Peer({ trickle: false });
        
        // 发送信号数据
        gameState.peer.signal(signal);
        
        // 生成自己的信号数据
        gameState.peer.on('signal', (data) => {
          gameState.peer.send(JSON.stringify({ type: 'signal', data: data }));
        });
        
        // 当收到数据时
        gameState.peer.on('data', (data) => {
          const message = JSON.parse(data.toString());
          
          if (message.type === 'choice') {
            // 处理对手的选择
            handleOpponentChoice(message.choice);
          }
        });
        
        // 当连接建立时
        gameState.peer.on('connect', () => {
          console.log('已连接到主机！游戏开始！');
          gameState.connection = gameState.peer;
          gameState.gameMode = 'p2p_client';
          startGame();
        });
        
      } catch (e) {
        console.log('信号数据格式错误，请重新输入！');
        setTimeout(joinP2PGame, 2000);
      }
    });
  });
}

// 处理对手的选择
function handleOpponentChoice(choice) {
  const opponentChoice = parseInt(choice);
  const playerChoice = 0; // 在P2P模式中，我们不需要玩家的选择来显示结果
  
  clearScreen();
  const choices = ['石头 🪨', '剪刀 ✂️', '布 📃'];
  
  console.log('================ 结果 ================');
  console.log(`你出了: ${choices[playerChoice] || '等待中...'}`);
  console.log(`对手出了: ${choices[opponentChoice - 1]}`);
  console.log('结果计算中...');
  console.log('====================================');
  
  // 设置轮到我出拳
  gameState.isMyTurn = true;
  
  setTimeout(() => {
    playRound();
  }, 2000);
}

// 启动游戏
console.log('启动石头剪刀布游戏...');
setTimeout(showStartScreen, 1000);