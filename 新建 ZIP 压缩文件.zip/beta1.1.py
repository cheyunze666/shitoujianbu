import tkinter as tk
from tkinter import messagebox
import random

class RockPaperScissorsGame:
    def __init__(self, root):
        self.root = root
        self.root.title("石头剪刀布")
        self.root.geometry("400x300")
        
        # 初始化分数
        self.player_score = 0
        self.ai_score = 0
        
        # 创建界面元素
        self.create_widgets()
        self.update_score_display()

    def create_widgets(self):
        # 标题标签
        self.title_label = tk.Label(self.root, text="石头剪刀布游戏", font=("Arial", 16, "bold"))
        self.title_label.pack(pady=10)
        
        # 分数显示
        self.score_label = tk.Label(self.root, text="玩家: 0  |  AI: 0", font=("Arial", 14))
        self.score_label.pack(pady=5)
        
        # 状态显示
        self.status_label = tk.Label(self.root, text="请选择你的出拳", font=("Arial", 12))
        self.status_label.pack(pady=10)
        
        # 按钮框架
        button_frame = tk.Frame(self.root)
        button_frame.pack(pady=15)
        
        # 游戏按钮
        self.rock_btn = tk.Button(button_frame, text="石头", width=10, 
                                 command=lambda: self.play_game(1))
        self.rock_btn.pack(side=tk.LEFT, padx=10)
        
        self.scissors_btn = tk.Button(button_frame, text="剪刀", width=10, 
                                    command=lambda: self.play_game(2))
        self.scissors_btn.pack(side=tk.LEFT, padx=10)
        
        self.paper_btn = tk.Button(button_frame, text="布", width=10, 
                                 command=lambda: self.play_game(3))
        self.paper_btn.pack(side=tk.LEFT, padx=10)
        
        # 结果标签
        self.result_label = tk.Label(self.root, text="", font=("Arial", 12))
        self.result_label.pack(pady=10)
        
        # 重新开始按钮（初始隐藏）
        self.restart_btn = tk.Button(self.root, text="重新开始", width=15, 
                                    command=self.reset_game, state=tk.DISABLED)
        self.restart_btn.pack(pady=10)

    def play_game(self, player_choice):
        # AI随机选择
        ai_choice = random.randint(1, 3)
        
        # 获取选择名称
        choices = {1: "石头", 2: "剪刀", 3: "布"}
        player_name = choices[player_choice]
        ai_name = choices[ai_choice]
        
        # 显示选择
        self.status_label.config(text=f"你选择了: {player_name}, AI选择了: {ai_name}")
        
        # 判断胜负
        result = self.determine_winner(player_choice, ai_choice)
        self.result_label.config(text=f"结果: {result}")
        
        # 更新分数
        if "赢" in result:
            self.player_score += 1
        elif "输" in result:
            self.ai_score += 1
        
        self.update_score_display()
        
        # 检查游戏是否结束
        if self.player_score >= 3 or self.ai_score >= 3:
            self.end_game()

    def determine_winner(self, player, ai):
        if player == ai:
            return "平局！"
        
        # 石头(1)赢剪刀(2), 剪刀(2)赢布(3), 布(3)赢石头(1)
        if (player == 1 and ai == 2) or \
           (player == 2 and ai == 3) or \
           (player == 3 and ai == 1):
            return "你赢了！"
        
        return "你输了！"

    def update_score_display(self):
        self.score_label.config(text=f"玩家: {self.player_score}  |  AI: {self.ai_score}")

    def end_game(self):
        # 禁用游戏按钮
        self.rock_btn.config(state=tk.DISABLED)
        self.scissors_btn.config(state=tk.DISABLED)
        self.paper_btn.config(state=tk.DISABLED)
        
        # 启用重新开始按钮
        self.restart_btn.config(state=tk.NORMAL)
        
        # 显示获胜信息
        winner = "玩家" if self.player_score >= 3 else "AI"
        messagebox.showinfo("游戏结束", f"{winner}获胜！\n最终比分: {self.player_score}-{self.ai_score}")

    def reset_game(self):
        # 重置分数
        self.player_score = 0
        self.ai_score = 0
        
        # 重置显示
        self.update_score_display()
        self.status_label.config(text="请选择你的出拳")
        self.result_label.config(text="")
        
        # 启用游戏按钮
        self.rock_btn.config(state=tk.NORMAL)
        self.scissors_btn.config(state=tk.NORMAL)
        self.paper_btn.config(state=tk.NORMAL)
        
        # 禁用重新开始按钮
        self.restart_btn.config(state=tk.DISABLED)

if __name__ == "__main__":
    root = tk.Tk()
    game = RockPaperScissorsGame(root)
    root.mainloop()