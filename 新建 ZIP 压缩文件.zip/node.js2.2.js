const readline = require('readline');
const WebSocket = require('ws');
const http = require('http');
const os = require('os');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');

// 游戏版本信息
const VERSION = "2.2";
const GITHUB_URL = "https://github.com/cheyunze666/shitoujianbu";
const GITEE_URL = "https://gitee.com/cheyunze/shitoujiandaobu";

// 创建缓存文件夹
const cacheDir = path.join(__dirname, '.rock-paper-scissors-cache');
if (!fs.existsSync(cacheDir)) {
  fs.mkdirSync(cacheDir);
}

// 用户数据文件路径
const usersFilePath = path.join(cacheDir, 'users.json');
const recordsFilePath = path.join(cacheDir, 'records.json');
const aiMemoryFilePath = path.join(cacheDir, 'ai_memory.json');

// 初始化数据文件
if (!fs.existsSync(usersFilePath)) {
  fs.writeFileSync(usersFilePath, '{}');
}
if (!fs.existsSync(recordsFilePath)) {
  fs.writeFileSync(recordsFilePath, '[]');
}
if (!fs.existsSync(aiMemoryFilePath)) {
  fs.writeFileSync(aiMemoryFilePath, '{}');
}

// 游戏状态和配置
let gameState = {
  playerScore: 0,
  opponentScore: 0,
  round: 1,
  maxRounds: 3,
  aiDifficulty: '中等', // 简单, 中等, 困难
  gameMode: null, // '单人', '局域网主机', '局域网客户端'
  playerId: uuidv4(),
  roomId: null,
  isMyTurn: false,
  server: null,
  wss: null,
  currentUser: null,
  opponentName: 'AI',
  lanStatus: '未连接'
};

// 创建命令行接口
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// 清屏函数
function clearScreen() {
  process.stdout.write('\x1Bc');
}

// 显示加载界面
function showLoadingScreen() {
  clearScreen();
  console.log('========================================');
  console.log('       🪨 ✂️ 📃 石头剪刀布游戏       ');
  console.log('========================================');
  console.log(`           版本 ${VERSION}           `);
  console.log('========================================');
  console.log('正在加载游戏，请稍候...');
  
  const loadingChars = ['|', '/', '-', '\\'];
  let i = 0;
  
  const interval = setInterval(() => {
    process.stdout.clearLine();
    process.stdout.cursorTo(0);
    process.stdout.write(`加载中 ${loadingChars[i++]}`);
    i = i % loadingChars.length;
  }, 100);
  
  // 模拟加载过程
  setTimeout(() => {
    clearInterval(interval);
    process.stdout.clearLine();
    process.stdout.cursorTo(0);
    showLoginScreen();
  }, 2000);
}

// 显示登录界面
function showLoginScreen() {
  clearScreen();
  console.log('========================================');
  console.log('           🪨 ✂️ 📃 石头剪刀布         ');
  console.log('========================================');
  console.log('1. 登录');
  console.log('2. 注册');
  console.log('3. 游客模式');
  console.log('4. 退出游戏');
  console.log('========================================');
  rl.question('请选择操作 (1-4): ', handleLoginMenu);
}

// 处理登录菜单
function handleLoginMenu(choice) {
  switch (choice) {
    case '1':
      loginUser();
      break;
    case '2':
      registerUser();
      break;
    case '3':
      gameState.currentUser = { 
        username: '游客', 
        isGuest: true,
        guestId: '游客-' + Math.random().toString(36).substr(2, 5)
      };
      showMainMenu();
      break;
    case '4':
    default:
      console.log('感谢游玩，再见！👋');
      exitGame();
  }
}

// 用户登录
function loginUser() {
  clearScreen();
  console.log('=============== 用户登录 ===============');
  
  rl.question('用户名: ', (username) => {
    rl.question('密码: ', (password) => {
      const users = JSON.parse(fs.readFileSync(usersFilePath, 'utf8'));
      
      if (users[username] && users[username].password === hashPassword(password)) {
        gameState.currentUser = { 
          username,
          isGuest: false
        };
        console.log('登录成功！');
        setTimeout(showMainMenu, 1000);
      } else {
        console.log('用户名或密码错误！');
        setTimeout(showLoginScreen, 1500);
      }
    });
  });
}

// 用户注册
function registerUser() {
  clearScreen();
  console.log('=============== 用户注册 ===============');
  
  rl.question('用户名: ', (username) => {
    rl.question('密码: ', (password) => {
      const users = JSON.parse(fs.readFileSync(usersFilePath, 'utf8'));
      
      if (users[username]) {
        console.log('用户名已存在！');
        setTimeout(showLoginScreen, 1500);
        return;
      }
      
      users[username] = {
        password: hashPassword(password),
        createdAt: new Date().toISOString()
      };
      
      fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2));
      console.log('注册成功！');
      gameState.currentUser = { 
        username,
        isGuest: false
      };
      setTimeout(showMainMenu, 1000);
    });
  });
}

// 密码哈希
function hashPassword(password) {
  return crypto.createHash('sha256').update(password).digest('hex');
}

// 显示主菜单
function showMainMenu() {
  clearScreen();
  console.log('========================================');
  console.log(`   欢迎回来，${gameState.currentUser.username}！   `);
  console.log(`           版本 ${VERSION}           `);
  console.log('========================================');
  
  // 游客模式菜单限制
  if (gameState.currentUser.isGuest) {
    console.log('1. 🎮 单人游戏');
    console.log('2. 📖 游戏规则');
    console.log('3. 👤 关于作者');
    console.log('4. 🔓 开源地址');
    console.log('5. 🚪 退出游戏');
    console.log('========================================');
    console.log('游客提示: 注册账号可解锁更多功能！');
    rl.question('请选择操作 (1-5): ', handleGuestMainMenu);
  } else {
    console.log('1. 🎮 单人游戏');
    console.log('2. 🌐 创建局域网房间');
    console.log('3. 🔌 加入局域网游戏');
    console.log('4. 📊 查看战绩');
    console.log('5. 📖 游戏规则');
    console.log('6. 👤 关于作者');
    console.log('7. 🔓 开源地址');
    console.log('8. 🚪 退出游戏');
    console.log('========================================');
    rl.question('请选择操作 (1-8): ', handleMainMenu);
  }
}

// 处理游客主菜单
function handleGuestMainMenu(choice) {
  switch (choice) {
    case '1':
      gameState.gameMode = '单人';
      selectDifficulty();
      break;
    case '2':
      showGameRules();
      break;
    case '3':
      showAboutAuthor();
      break;
    case '4':
      showOpenSource();
      break;
    case '5':
      console.log('感谢游玩，再见！👋');
      exitGame();
      break;
    default:
      console.log('无效的选择，请重新输入！');
      setTimeout(showMainMenu, 1500);
  }
}

// 处理主菜单
function handleMainMenu(choice) {
  switch (choice) {
    case '1':
      gameState.gameMode = '单人';
      selectDifficulty();
      break;
    case '2':
      createLanRoom();
      break;
    case '3':
      joinLanGame();
      break;
    case '4':
      showRecords();
      break;
    case '5':
      showGameRules();
      break;
    case '6':
      showAboutAuthor();
      break;
    case '7':
      showOpenSource();
      break;
    case '8':
      console.log('感谢游玩，再见！👋');
      exitGame();
      break;
    default:
      console.log('无效的选择，请重新输入！');
      setTimeout(showMainMenu, 1500);
  }
}

// 退出游戏
function exitGame() {
  if (gameState.server) {
    gameState.server.close();
    gameState.server = null;
  }
  if (gameState.wss) {
    gameState.wss.close();
    gameState.wss = null;
  }
  console.log(`感谢使用石头剪刀布游戏 v${VERSION}`);
  console.log(`开源地址: GitHub: ${GITHUB_URL}`);
  console.log(`         Gitee:  ${GITEE_URL}`);
  rl.close();
  process.exit(0);
}

// 选择AI难度
function selectDifficulty() {
  clearScreen();
  console.log('============= 选择AI难度 =============');
  console.log('1. 🟢 简单 - AI随机出拳');
  console.log('2. 🟡 中等 - AI有策略地出拳');
  console.log('3. 🔴 困难 - AI会学习你的出拳习惯');
  console.log('====================================');
  rl.question('请选择难度 (1-3): ', (choice) => {
    switch (choice) {
      case '1':
        gameState.aiDifficulty = '简单';
        break;
      case '2':
        gameState.aiDifficulty = '中等';
        break;
      case '3':
        gameState.aiDifficulty = '困难';
        break;
      default:
        gameState.aiDifficulty = '中等';
    }
    startGame();
  });
}

// 开始游戏
function startGame() {
  gameState.playerScore = 0;
  gameState.opponentScore = 0;
  gameState.round = 1;
  playRound();
}

// 进行一局游戏
function playRound() {
  clearScreen();
  console.log(`============= 第 ${gameState.round} 局 =============`);
  console.log(`玩家: ${gameState.playerScore}  |  ${getOpponentName()}: ${gameState.opponentScore}`);
  console.log('====================================');
  console.log('1. 🪨 石头');
  console.log('2. ✂️ 剪刀');
  console.log('3. 📃 布');
  console.log('0. ↩️ 返回主菜单');
  console.log('====================================');
  
  // 在联机模式中，如果不是自己的回合，则等待
  if (gameState.gameMode !== '单人' && !gameState.isMyTurn) {
    console.log('\n等待对手出拳中...⏳');
    return;
  }
  
  rl.question('请选择你的出拳 (1-3) 或返回 (0): ', (choice) => {
    if (choice === '0') {
      resetGameState();
      showMainMenu();
      return;
    }
    
    const playerChoice = parseInt(choice);
    if (playerChoice < 1 || playerChoice > 3) {
      console.log('无效的选择，请重新输入！');
      setTimeout(playRound, 1500);
      return;
    }
    
    if (gameState.gameMode === '单人') {
      const aiChoice = generateAIChoice(playerChoice);
      const result = determineWinner(playerChoice, aiChoice);
      displayResult(playerChoice, aiChoice, result);
    } else if (gameState.gameMode.startsWith('局域网')) {
      // 局域网模式：发送选择给服务器
      if (gameState.connection) {
        gameState.connection.send(JSON.stringify({
          type: 'choice',
          choice: playerChoice,
          playerId: gameState.playerId
        }));
        console.log('已发送你的选择，等待对手...');
        gameState.isMyTurn = false;
      }
    }
  });
}

// 获取对手名称
function getOpponentName() {
  if (gameState.gameMode === '单人') return 'AI';
  if (gameState.gameMode === '局域网主机') return gameState.opponentName;
  if (gameState.gameMode === '局域网客户端') return gameState.opponentName;
  return '对手';
}

// 生成AI的选择
function generateAIChoice(playerChoice) {
  // 获取用户的AI记忆
  const aiMemory = JSON.parse(fs.readFileSync(aiMemoryFilePath, 'utf8'));
  let username = gameState.currentUser.isGuest ? 
    gameState.currentUser.guestId : 
    gameState.currentUser.username;
  
  if (!aiMemory[username]) {
    aiMemory[username] = {
      totalGames: 0,
      choices: []
    };
  }
  
  const userMemory = aiMemory[username];
  
  switch (gameState.aiDifficulty) {
    case '简单':
      // 完全随机
      return Math.floor(Math.random() * 3) + 1;
    case '困难':
      // 困难模式：尝试预测玩家行为
      if (userMemory.choices.length < 5) {
        // 数据不足时随机
        return Math.floor(Math.random() * 3) + 1;
      }
      
      // 分析玩家最常出的拳
      const choiceCount = [0, 0, 0]; // 石头, 剪刀, 布
      userMemory.choices.slice(-10).forEach(choice => {
        choiceCount[choice - 1]++;
      });
      
      const mostCommonChoice = choiceCount.indexOf(Math.max(...choiceCount)) + 1;
      
      // 反制玩家最常出的拳
      return (mostCommonChoice % 3) + 1;
    case '中等':
    default:
      // 中等模式：有一定策略
      if (Math.random() < 0.6) {
        return (playerChoice % 3) + 1;
      }
      return Math.floor(Math.random() * 3) + 1;
  }
}

// 判断胜负
function determineWinner(player, opponent) {
  // 石头(1) > 剪刀(2)
  // 剪刀(2) > 布(3)
  // 布(3) > 石头(1)
  if (player === opponent) return '平局';
  
  if (
    (player === 1 && opponent === 2) ||
    (player === 2 && opponent === 3) ||
    (player === 3 && opponent === 1)
  ) {
    return '胜利';
  }
  
  return '失败';
}

// 显示结果
function displayResult(playerChoice, opponentChoice, result) {
  clearScreen();
  const choices = ['石头 🪨', '剪刀 ✂️', '布 📃'];
  
  console.log('================ 结果 ================');
  console.log(`你出了: ${choices[playerChoice - 1]}`);
  console.log(`${getOpponentName()}出了: ${choices[opponentChoice - 1]}`);
  
  switch (result) {
    case '胜利':
      gameState.playerScore++;
      console.log('🎉 你赢了这一局！');
      break;
    case '失败':
      gameState.opponentScore++;
      console.log('😢 你输了这一局！');
      break;
    case '平局':
      console.log('🤝 平局！');
      break;
  }
  
  console.log('====================================');
  
  // 更新AI记忆
  if (gameState.gameMode === '单人') {
    const aiMemory = JSON.parse(fs.readFileSync(aiMemoryFilePath, 'utf8'));
    let username = gameState.currentUser.isGuest ? 
      gameState.currentUser.guestId : 
      gameState.currentUser.username;
    
    if (!aiMemory[username]) {
      aiMemory[username] = {
        totalGames: 0,
        choices: []
      };
    }
    
    aiMemory[username].choices.push(playerChoice);
    aiMemory[username].totalGames++;
    fs.writeFileSync(aiMemoryFilePath, JSON.stringify(aiMemory, null, 2));
  }
  
  // 检查游戏是否结束
  if (gameState.playerScore >= gameState.maxRounds || gameState.opponentScore >= gameState.maxRounds) {
    setTimeout(endGame, 2000);
  } else {
    gameState.round++;
    setTimeout(playRound, 2000);
  }
}

// 结束游戏
function endGame() {
  clearScreen();
  console.log('============== 游戏结束 ==============');
  console.log(`最终比分: 玩家 ${gameState.playerScore} - ${gameState.opponentScore} ${getOpponentName()}`);
  
  let result = '平局';
  if (gameState.playerScore > gameState.opponentScore) {
    console.log('🏆 恭喜你获得胜利！');
    result = '胜利';
  } else if (gameState.playerScore < gameState.opponentScore) {
    console.log('💔 很遗憾，你输了！');
    result = '失败';
  } else {
    console.log('🤝 平局！势均力敌！');
  }
  
  // 保存游戏记录（游客模式不保存）
  if (!gameState.currentUser.isGuest) {
    const records = JSON.parse(fs.readFileSync(recordsFilePath, 'utf8'));
    
    records.push({
      username: gameState.currentUser.username,
      date: new Date().toISOString(),
      mode: gameState.gameMode,
      difficulty: gameState.aiDifficulty,
      result: result,
      playerScore: gameState.playerScore,
      opponentScore: gameState.opponentScore,
      opponent: getOpponentName()
    });
    
    fs.writeFileSync(recordsFilePath, JSON.stringify(records, null, 2));
  }
  
  console.log('====================================');
  rl.question('按回车键返回主菜单...', () => {
    resetGameState();
    showMainMenu();
  });
}

// 重置游戏状态
function resetGameState() {
  if (gameState.server) {
    gameState.server.close();
    gameState.server = null;
  }
  if (gameState.wss) {
    gameState.wss.close();
    gameState.wss = null;
  }
  gameState.connection = null;
  gameState.roomId = null;
  gameState.isMyTurn = false;
  gameState.lanStatus = '未连接';
}

// 显示游戏规则
function showGameRules() {
  clearScreen();
  console.log('============= 游戏规则 =============');
  console.log('1. 石头、剪刀、布分别用数字代表:');
  console.log('   🪨 1 - 石头');
  console.log('   ✂️ 2 - 剪刀');
  console.log('   📃 3 - 布');
  console.log('2. 胜负规则:');
  console.log('   石头(1) 赢 剪刀(2)');
  console.log('   剪刀(2) 赢 布(3)');
  console.log('   布(3) 赢 石头(1)');
  console.log('3. 游戏采用三局两胜制');
  console.log('4. 游戏模式:');
  console.log('   - 单人模式: 与AI对战');
  console.log('   - 局域网联机: 在同一个网络下与朋友对战');
  console.log('====================================');
  rl.question('按回车键返回主菜单...', showMainMenu);
}

// 显示关于作者
function showAboutAuthor() {
  clearScreen();
  console.log('============= 关于作者 =============');
  console.log('作者: 烂香蕉 🍌');
  console.log('简介: 一个热爱编程的游戏开发者');
  console.log(`版本: ${VERSION}`);
  console.log('创作理念: 创造有趣且富有挑战性的游戏体验');
  console.log('特别提示: 在困难模式下，AI会学习你的出拳习惯');
  console.log('====================================');
  rl.question('按回车键返回主菜单...', showMainMenu);
}

// 显示开源地址
function showOpenSource() {
  clearScreen();
  console.log('============= 开源地址 =============');
  console.log('本游戏完全开源，代码托管在以下平台:');
  console.log(`GitHub: ${GITHUB_URL}`);
  console.log(`Gitee:  ${GITEE_URL}`);
  console.log('欢迎贡献代码或提出改进建议！');
  console.log('====================================');
  rl.question('按回车键返回主菜单...', showMainMenu);
}

// 显示战绩
function showRecords() {
  // 游客模式无法查看战绩
  if (gameState.currentUser.isGuest) {
    clearScreen();
    console.log('============= 游客限制 =============');
    console.log('游客模式无法查看战绩！');
    console.log('请注册或登录账号以解锁此功能。');
    console.log('====================================');
    rl.question('按回车键返回主菜单...', showMainMenu);
    return;
  }
  
  clearScreen();
  console.log('============= 我的战绩 =============');
  
  const records = JSON.parse(fs.readFileSync(recordsFilePath, 'utf8'));
  const userRecords = records.filter(r => r.username === gameState.currentUser.username);
  
  if (userRecords.length === 0) {
    console.log('暂无游戏记录');
  } else {
    userRecords.slice(-10).reverse().forEach((record, index) => {
      console.log('------------------------------------');
      console.log(`日期: ${new Date(record.date).toLocaleString()}`);
      console.log(`模式: ${record.mode} | 难度: ${record.difficulty || '无'}`);
      console.log(`对手: ${record.opponent}`);
      console.log(`比分: ${record.playerScore} - ${record.opponentScore}`);
      console.log(`结果: ${record.result}`);
    });
  }
  
  console.log('====================================');
  rl.question('按回车键返回主菜单...', showMainMenu);
}

// 创建局域网房间
function createLanRoom() {
  // 游客模式无法创建房间
  if (gameState.currentUser.isGuest) {
    clearScreen();
    console.log('============= 游客限制 =============');
    console.log('游客模式无法创建局域网房间！');
    console.log('请注册或登录账号以解锁此功能。');
    console.log('====================================');
    rl.question('按回车键返回主菜单...', showMainMenu);
    return;
  }
  
  clearScreen();
  console.log('========= 创建局域网游戏房间 =========');
  
  // 获取本机IP地址
  const networkInterfaces = os.networkInterfaces();
  let ipAddress = '127.0.0.1';
  
  Object.keys(networkInterfaces).forEach((interfaceName) => {
    networkInterfaces[interfaceName].forEach((network) => {
      if (network.family === 'IPv4' && !network.internal) {
        ipAddress = network.address;
      }
    });
  });
  
  console.log(`你的IP地址: ${ipAddress}`);
  
  rl.question('请输入房间名称: ', (roomName) => {
    gameState.roomId = roomName;
    
    rl.question('请输入端口号 (默认: 8080): ', (port) => {
      const portNumber = port || 8080;
      
      // 创建HTTP服务器和WebSocket服务器
      gameState.server = http.createServer();
      gameState.wss = new WebSocket.Server({ server: gameState.server });
      
      let player1 = null;
      let player2 = null;
      
      gameState.wss.on('connection', (ws) => {
        // 分配玩家
        if (!player1) {
          player1 = ws;
          console.log('玩家1已连接！');
          ws.send(JSON.stringify({ 
            type: 'role', 
            role: 'player1',
            opponent: gameState.currentUser.username
          }));
        } else if (!player2) {
          player2 = ws;
          console.log('玩家2已连接！游戏开始！');
          ws.send(JSON.stringify({ 
            type: 'role', 
            role: 'player2',
            opponent: gameState.currentUser.username
          }));
          
          // 通知玩家1游戏开始
          player1.send(JSON.stringify({ 
            type: 'start',
            opponent: gameState.opponentName
          }));
          player2.send(JSON.stringify({ 
            type: 'start',
            opponent: gameState.opponentName
          }));
          
          // 设置游戏状态
          gameState.gameMode = '局域网主机';
          gameState.connection = player1; // 主机作为玩家1
          gameState.isMyTurn = true;
          startGame();
        } else {
          console.log('房间已满，拒绝连接');
          ws.close();
        }
        
        ws.on('message', (message) => {
          const data = JSON.parse(message);
          
          if (data.type === 'choice') {
            // 转发选择给对手
            if (ws === player1 && player2) {
              player2.send(JSON.stringify({ 
                type: 'opponent_choice', 
                choice: data.choice 
              }));
            } else if (ws === player2 && player1) {
              player1.send(JSON.stringify({ 
                type: 'opponent_choice', 
                choice: data.choice 
              }));
            }
          }
        });
        
        ws.on('close', () => {
          if (ws === player1) {
            player1 = null;
            console.log('玩家1断开连接');
          } else if (ws === player2) {
            player2 = null;
            console.log('玩家2断开连接');
          }
        });
      });
      
      gameState.server.listen(portNumber, () => {
        console.log(`房间 "${roomName}" 已创建，等待玩家加入...`);
        console.log(`其他玩家可以使用IP: ${ipAddress} 和端口: ${portNumber} 加入游戏`);
        console.log('等待连接中...');
      });
    });
  });
}

// 加入局域网游戏
function joinLanGame() {
  // 游客模式无法加入游戏
  if (gameState.currentUser.isGuest) {
    clearScreen();
    console.log('============= 游客限制 =============');
    console.log('游客模式无法加入局域网游戏！');
    console.log('请注册或登录账号以解锁此功能。');
    console.log('====================================');
    rl.question('按回车键返回主菜单...', showMainMenu);
    return;
  }
  
  clearScreen();
  console.log('============ 加入局域网游戏 ===========');
  
  rl.question('请输入主机IP地址: ', (ip) => {
    rl.question('请输入端口号 (默认: 8080): ', (port) => {
      const portNumber = port || 8080;
      const ws = new WebSocket(`ws://${ip}:${portNumber}`);
      
      ws.on('open', () => {
        console.log('已连接到主机！');
      });
      
      ws.on('message', (message) => {
        const data = JSON.parse(message);
        
        if (data.type === 'role') {
          gameState.gameMode = '局域网客户端';
          gameState.connection = ws;
          gameState.opponentName = data.opponent;
          console.log(`你的角色: ${data.role}`);
        }
        else if (data.type === 'start') {
          gameState.opponentName = data.opponent;
          console.log('游戏开始！');
          gameState.isMyTurn = (gameState.gameMode === '局域网客户端');
          startGame();
        }
        else if (data.type === 'opponent_choice') {
          const opponentChoice = parseInt(data.choice);
          
          clearScreen();
          const choices = ['石头 🪨', '剪刀 ✂️', '布 📃'];
          
          console.log('================ 结果 ================');
          console.log(`你出了: ${choices[0] || '等待中...'}`);
          console.log(`对手出了: ${choices[opponentChoice - 1]}`);
          console.log('结果计算中...');
          console.log('====================================');
          
          // 设置轮到我出拳
          gameState.isMyTurn = true;
          
          setTimeout(() => {
            playRound();
          }, 2000);
        }
      });
      
      ws.on('error', (error) => {
        console.log('连接失败，请检查IP和端口是否正确');
        console.log('错误信息:', error.message);
        rl.question('按回车键返回主菜单...', showMainMenu);
      });
    });
  });
}

// 启动游戏
showLoadingScreen();