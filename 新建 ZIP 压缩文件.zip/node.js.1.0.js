const readline = require('readline');
const WebSocket = require('ws');
const http = require('http');
const os = require('os');

// 游戏状态和配置
let gameState = {
  playerScore: 0,
  aiScore: 0,
  round: 1,
  maxRounds: 3,
  aiDifficulty: 'medium', // easy, medium, hard
  gameMode: null, // 'single', 'host', 'client'
  ws: null,
  server: null
};

// 创建命令行接口
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// 清屏函数
function clearScreen() {
  process.stdout.write('\x1Bc');
}

// 显示开始界面
function showStartScreen() {
  clearScreen();
  console.log('========================================');
  console.log('        🪨 ✂️ 📃石头剪刀布游戏 - 终极版         ');
  console.log('========================================');
  console.log('1. 🎮单人游戏');
  console.log('2. 🌐创建联机房间');
  console.log('3. 🔗加入联机游戏');
  console.log('4. 📖游戏规则');
  console.log('5. 👤关于作者');
  console.log('6. 🔓开源地址');
  console.log('7. 🚪退出游戏');
  console.log('========================================');
  rl.question('请选择操作 (1-7): ', handleStartMenu);
}

// 处理开始菜单选择
function handleStartMenu(choice) {
  switch (choice) {
    case '1':
      gameState.gameMode = 'single';
      selectDifficulty();
      break;
    case '2':
      startHostGame();
      break;
    case '3':
      joinMultiplayerGame();
      break;
    case '4':
      showGameRules();
      break;
    case '5':
      showAboutAuthor();
      break;
    case '6':
      showOpenSource();
      break;
    case '7':
      default:
      console.log('感谢游玩，再见👋！');
      rl.close();
      if (gameState.server) gameState.server.close();
      if (gameState.ws) gameState.ws.close();
      process.exit(0);
  }
}

// 选择AI难度
function selectDifficulty() {
  clearScreen();
  console.log('============= 选择AI难度 =============');
  console.log('1. 🟢简单 - AI随机出拳');
  console.log('2. 🟡中等 - AI有策略地出拳');
  console.log('3. 🔴困难 - AI会预测你的出拳');
  console.log('====================================');
  rl.question('请选择难度 (1-3): ', (choice) => {
    switch (choice) {
      case '1':
        gameState.aiDifficulty = 'easy';
        break;
      case '2':
        gameState.aiDifficulty = 'medium';
        break;
      case '3':
        gameState.aiDifficulty = 'hard';
        break;
      default:
        gameState.aiDifficulty = 'medium';
    }
    startGame();
  });
}

// 开始游戏
function startGame() {
  gameState.playerScore = 0;
  gameState.aiScore = 0;
  gameState.round = 1;
  playRound();
}

// 进行一局游戏
function playRound() {
  clearScreen();
  console.log(`============= 第 ${gameState.round} 局 =============`);
  console.log(`玩家: ${gameState.playerScore}  |  ${gameState.gameMode === 'single' ? 'AI' : '对手'}: ${gameState.aiScore}`);
  console.log('====================================');
  console.log('1. 🪨石头');
  console.log('2. ✂️剪刀');
  console.log('3. 📃布');
  console.log('0. ↩️返回主菜单');
  console.log('====================================');
  
  rl.question('请选择你的出拳 (1-3) 或返回 (0): ', (choice) => {
    if (choice === '0') {
      showStartScreen();
      return;
    }
    
    const playerChoice = parseInt(choice);
    if (playerChoice < 1 || playerChoice > 3) {
      console.log('无效的选择，请重新输入！');
      setTimeout(playRound, 1500);
      return;
    }
    
    if (gameState.gameMode === 'single') {
      const aiChoice = generateAIChoice(playerChoice);
      const result = determineWinner(playerChoice, aiChoice);
      displayResult(playerChoice, aiChoice, result);
    } else {
      // 联机模式下发送选择给对手
      gameState.ws.send(JSON.stringify({ type: 'choice', choice: playerChoice }));
      console.log('已发送你的选择，等待对手...');
    }
  });
}

// 生成AI的选择
function generateAIChoice(playerChoice) {
  switch (gameState.aiDifficulty) {
    case 'easy':
      // 完全随机
      return Math.floor(Math.random() * 3) + 1;
    case 'hard':
      // 困难模式：尝试预测玩家行为并反制
      // 有40%几率反制玩家最常出的拳，30%几率出平局，30%几率随机
      const rand = Math.random();
      if (rand < 0.4) {
        // 反制玩家最常出的拳（这里简化为反制上一局的选择）
        return (playerChoice % 3) + 1;
      } else if (rand < 0.7) {
        return playerChoice; // 平局
      } else {
        return Math.floor(Math.random() * 3) + 1;
      }
    case 'medium':
    default:
      // 中等模式：有一定策略，但不完全预测
      // 60%几率出能赢上一局的拳，40%几率随机
      if (Math.random() < 0.6) {
        // 假设玩家倾向于重复出拳
        return (playerChoice % 3) + 1;
      }
      return Math.floor(Math.random() * 3) + 1;
  }
}

// 判断胜负
function determineWinner(player, ai) {
  // 石头(1) > 剪刀(2)
  // 剪刀(2) > 布(3)
  // 布(3) > 石头(1)
  if (player === ai) return 'draw';
  
  if (
    (player === 1 && ai === 2) ||
    (player === 2 && ai === 3) ||
    (player === 3 && ai === 1)
  ) {
    return 'win';
  }
  
  return 'lose';
}

// 显示结果
function displayResult(playerChoice, aiChoice, result) {
  clearScreen();
  const choices = ['石头 🪨', '剪刀 ✂️', '布 📃'];

  console.log('================ 结果 ================');
  console.log(`你出了: ${choices[playerChoice - 1]}`);
  console.log(`${gameState.gameMode === 'single' ? 'AI' : '对手'}出了: ${choices[aiChoice - 1]}`);
  
  switch (result) {
    case 'win':
      gameState.playerScore++;
      console.log('你赢了这一局！🎉');
      break;
    case 'lose':
      gameState.aiScore++;
      console.log('你输了这一局！😢');
      break;
    case 'draw':
      console.log('平局！🤝');
      break;
  }
  
  console.log('====================================');
  
  // 检查游戏是否结束
  if (gameState.playerScore >= gameState.maxRounds || gameState.aiScore >= gameState.maxRounds) {
    setTimeout(endGame, 2000);
  } else {
    gameState.round++;
    setTimeout(playRound, 2000);
  }
}

// 结束游戏
function endGame() {
  clearScreen();
  console.log('============== 游戏结束 ==============');
  console.log(`最终比分: 玩家 ${gameState.playerScore} - ${gameState.aiScore} ${gameState.gameMode === 'single' ? 'AI' : '对手'}`);
  
  if (gameState.playerScore > gameState.aiScore) {
    console.log('恭喜你获得胜利！🏆');
  } else if (gameState.playerScore < gameState.aiScore) {
    console.log('很遗憾，你输了！💔');
  } else {
    console.log('平局！势均力敌！🤝');
  }
  
  console.log('====================================');
  rl.question('按回车键返回主菜单...', () => {
    showStartScreen();
  });
}

// 显示游戏规则
function showGameRules() {
  clearScreen();
  console.log('============= 游戏规则 =============');
  console.log('1. 石头、剪刀、布分别用数字代表:');
  console.log('  🪨 1 - 石头');
  console.log('  ✂️2 - 剪刀');
  console.log('  📃 3 - 布');
  console.log('2. 胜负规则:');
  console.log('   石头(1) 赢 剪刀(2)');
  console.log('   剪刀(2) 赢 布(3)');
  console.log('   布(3) 赢 石头(1)');
  console.log('3. 游戏采用三局两胜制');
  console.log('4. 游戏模式:');
  console.log('   - 单人模式: 与AI对战');
  console.log('   - 联机模式: 与局域网内的朋友对战');
  console.log('====================================');
  rl.question('按回车键返回主菜单...', showStartScreen);
}

// 显示关于作者
function showAboutAuthor() {
  clearScreen();
  console.log('============= 关于=============');
  console.log('作者: 烂香蕉🍌');
  console.log('简介: 一个热爱编程的游戏开发者');
  console.log('创作理念: 创造有趣且富有挑战性的游戏体验');
  console.log('特别提示: 本游戏中的AI具有学习能力，难度越高越聪明！游戏版本号：1.0');
  console.log('====================================');
  rl.question('按回车键返回主菜单...', showStartScreen);
}

// 显示开源地址
function showOpenSource() {
  clearScreen();
  console.log('============= 开源地址 =============');
  console.log('本游戏完全开源，代码托管在GitHub:');
  console.log('https://github.com/cheyunze666/-');
  console.log('欢迎贡献代码或提出改进建议！');
  console.log('====================================');
  rl.question('按回车键返回主菜单...', showStartScreen);
}

// 创建主机游戏
function startHostGame() {
  clearScreen();
  console.log('========= 创建联机游戏房间 =========');
  
  // 获取本机IP地址
  const networkInterfaces = os.networkInterfaces();
  let ipAddress = '127.0.0.1';
  
  Object.keys(networkInterfaces).forEach((interfaceName) => {
    networkInterfaces[interfaceName].forEach((network) => {
      if (network.family === 'IPv4' && !network.internal) {
        ipAddress = network.address;
      }
    });
  });
  
  console.log(`你的IP地址: ${ipAddress}`);
  
  rl.question('请输入端口号 (默认: 8080): ', (port) => {
    const portNumber = port || 8080;
    
    // 创建HTTP服务器和WebSocket服务器
    gameState.server = http.createServer();
    const wss = new WebSocket.Server({ server: gameState.server });
    
    wss.on('connection', (ws) => {
      gameState.gameMode = 'host';
      gameState.ws = ws;
      console.log('对手已连接！');
      
      ws.on('message', (message) => {
        const data = JSON.parse(message);
        if (data.type === 'choice') {
          const aiChoice = generateAIChoice(parseInt(data.choice));
          const result = determineWinner(parseInt(data.choice), aiChoice);
          
          // 发送结果给客户端
          ws.send(JSON.stringify({
            type: 'result',
            playerChoice: parseInt(data.choice),
            aiChoice,
            result
          }));
          
          // 更新分数
          if (result === 'lose') gameState.aiScore++;
          else if (result === 'win') gameState.playerScore++;
          
          // 检查游戏是否结束
          if (gameState.playerScore >= gameState.maxRounds || gameState.aiScore >= gameState.maxRounds) {
            endGame();
          } else {
            gameState.round++;
          }
        }
      });
      
      // 开始游戏
      startGame();
    });
    
    gameState.server.listen(portNumber, () => {
      console.log(`房间已创建，等待其他玩家加入...`);
      console.log(`其他玩家可以使用IP: ${ipAddress} 和端口: ${portNumber} 加入游戏`);
      console.log('等待连接中...');
    });
  });
}

// 加入联机游戏
function joinMultiplayerGame() {
  clearScreen();
  console.log('============ 加入联机游戏 ===========');
  
  rl.question('请输入主机IP地址: ', (ip) => {
    rl.question('请输入端口号 (默认: 8080): ', (port) => {
      const portNumber = port || 8080;
      const ws = new WebSocket(`ws://${ip}:${portNumber}`);
      
      ws.on('open', () => {
        gameState.gameMode = 'client';
        gameState.ws = ws;
        console.log('已连接到主机！');
        startGame();
      });
      
      ws.on('message', (message) => {
        const data = JSON.parse(message);
        if (data.type === 'result') {
          clearScreen();
          const choices = ['石头 🪨', '剪刀 ✂️', '布 📃'];
          
          console.log('================ 结果 ================');
          console.log(`你出了: ${choices[data.playerChoice - 1]}`);
          console.log(`对手出了: ${choices[data.aiChoice - 1]}`);
          
          switch (data.result) {
            case 'win':
              gameState.playerScore++;
              console.log('你赢了这一局！🎉');
              break;
            case 'lose':
              gameState.aiScore++;
              console.log('你输了这一局！😢');
              break;
            case 'draw':
              console.log('平局！🤝');
              break;
          }
          
          console.log('====================================');
          
          // 检查游戏是否结束
          if (gameState.playerScore >= gameState.maxRounds || gameState.aiScore >= gameState.maxRounds) {
            setTimeout(endGame, 2000);
          } else {
            gameState.round++;
            setTimeout(playRound, 2000);
          }
        }
      });
      
      ws.on('error', (error) => {
        console.log('连接失败，请检查IP和端口是否正确');
        console.log('错误信息:', error.message);
        rl.question('按回车键返回主菜单...', showStartScreen);
      });
    });
  });
}

// 启动游戏
console.log('启动石头剪刀布游戏...');
setTimeout(showStartScreen, 1000);