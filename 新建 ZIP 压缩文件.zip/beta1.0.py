import random; wins, losses = 0, 0; print("石头(1), 剪刀(2), 布(3)"); reset = lambda: (0, 0);  # 初始化
while True:  # 主游戏循环
    if wins >= 3: print("你赢了3局! 获胜!"); wins, losses = reset()
    if losses >= 3: print("AI赢了3局! 你输了!"); wins, losses = reset()
    cmd = input(f"[{wins}-{losses}] 出拳 (1/2/3): ")  # 显示当前比分
    if cmd not in ["1", "2", "3"]: print("无效输入!"); continue
    ai = random.choice([1, 2, 3]); player = int(cmd)
    hands = ["石头", "剪刀", "布"]; print(f"你出:{hands[player-1]}  AI出:{hands[ai-1]}")
    if player == ai: print("平局!")
    elif (player==1 and ai==2) or (player==2 and ai==3) or (player==3 and ai==1): 
        print("你赢!"); wins += 1
    else: print("AI赢!"); losses += 1